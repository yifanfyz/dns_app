
from flask import Flask, request, jsonify
from socket import *

app = Flask(__name__)

def fibonacci_algorithm(n):
    if(n<0): print("n should be greater than 0")
    elif n == 1: return 0
    elif n == 2: return 1
    else: return fibonacci_algorithm(n-1)+fibonacci_algorithm(n-2)
    
    
@app.route('/register', methods = ['PUT'])
def register():
    registration = request.get_json();
    hostname = registration.get('hostname');
    ip = registration.get('ip');
    as_ip = registration.get('as_ip');
    as_port = registration.get('as_port');
    
    if hostname and ip and as_ip and as_port:
        client_socket = socket(AF_INET, SOCK_DGRAM)
        message = "TYPE=A\nName={}\nValue={}\nTTL=10".format(hostname, ip, as_ip, as_port)
        client_socket.sendto(message.encode(), (as_ip, as_port))
        received_message, server_address = client_socket.recvfrom(2048)
        client_socket.close()
        
        if received_message.decode() == "SUCCESS": return jsonify('SUCCESS'), 201
        else: return jsonify('FAILED'), 500
    
    else: return jsonify('missing parameter'), 400
        
        
        
@app.route('/fibonacci', methods = ['GET'])
def fibonacci():
    number = request.args.get('number')
    if number: 
        print("received request number: "+ number)
        return jsonify(fibonacci_algorithm(int(number))), 200
    else: 
        return jsonify("To do fibonacci, need a positive number"), 400
    
    
app.run(host='0.0.0.0', port=9090, debug = True)