from flask import Flask, request, jsonify
from socket import *
import requests


app = Flask(__name__)


@app.route('/fibonacci', methods = ['GET'])
def fibonacci():
        hostname = request.args.get('hostname')
        fs_port = request.args.get('fs_port')
        number = request.args.get('number')
        as_ip = request.args.get('as_ip')
        as_port = request.args.get('as_port')
        print("received request: {},{},{},{},{}"+ format(hostname, fs_port, number, as_ip, as_port))
        
        if hostname and fs_port and number and as_ip and as_port: 
            
            client_socket = socket(AF_INET, SOCK_DGRAM)
            message = "TYPE=A\nName="+hostname
            client_socket.sendto(message.encode(), (as_ip, as_port))
            received_message, server_address = client_socket.recvfrom(2048)
            print("receive modified message: "+received_message.decode())
            client_socket.close()
            message_decoded = received_message.decode()
            message_info = message_decoded[1].split('\n')
            message_name = message_info[1].split('=')[1]
            message_value = message_info[2].split('=')[1]
            message_request = request.get("http://"+message_value+":"+fs_port+"/fibonacci?number="+number)
            
            return jsonify(message_request.json()), 200
        
        else:  return jsonify("missing parameter"), 400
        
app.run(host='0.0.0.0', port = 8080, debug = True)