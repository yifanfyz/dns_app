from socket import *


server_port = 53533
server_socket = socket(AF_INET, SOCK_DGRAM)
server_socket.bind(('', server_port))
print ("The server is ready to receive")
db = {} #store name and value 
while True:
    message, client_address = server_socket.recvfrom(2048)
    message_decoded = message.decode()
    print("received message: "+message_decoded)
    if 'VALUE' in message_decoded:
        message_info = message_decoded.split('\n')
        message_name = message_info[1].split('=')[1]
        message_value = message_info[2].split('=')[1]
        print("new registration: name: " + message_name + "\tvalue: "+message_value)
        db[message_name] = message_value
        server_socket.sendto("SUCCESS".encode(), client_address)
    else:
        message_info = message_decoded.split('\n')
        message_name = message_info[1].split('=')[1]
        
        if message_name in db: 
            send = "TYPE=A\nNAME="+ message_name + "\nVALUE="+db[message_name]+"\nTTL=10"
            server_socket.sendto(send.encode(), client_address)
        
        
        
        
    
    